package com;

import com.service.impl.IMailServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.mail.MessagingException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AppStart.class)
public class AppStartTest {

    @Autowired
    private IMailServiceImpl iMailService;

    @Test
    public void test() throws MessagingException {
        iMailService.sendAttachmentMail("*****",
                "test 主题",
                "邮件内容",
                "");

    }

}
